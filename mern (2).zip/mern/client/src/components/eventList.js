import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
 
const Event = (props) => (
 <tr>
   <td>{props.event.name}</td>
   <td>{props.event.date}</td>
   <td>
     <Link className="btn btn-link" to={`/guests/${props.event._id}`}>Lankytojų sąrašas</Link> |
     <Link className="btn btn-link" to={`/create/${props.event._id}`}>Pridėti lankytoją</Link>
   </td>
 </tr>
);
 
export default function EventList() {
 const [events, setEvents] = useState([]);
 
 // This method fetches the events from the database.
 useEffect(() => {
   async function getEvents() {
     const response = await fetch(`http://localhost:5000/event/`);
 
     if (!response.ok) {
       const message = `An error occurred: ${response.statusText}`;
       window.alert(message);
       return;
     }
 
     const events = await response.json();
     setEvents(events);
   }
 
   getEvents();
 
   return;
 }, [events.length]);
 
 // This method will map out the events on the table
 function eventList() {
   return events.map((event) => {
     return (
       <Event
         event={event}
         key={event._id}
       />
     );
   });
 }
 
 // This following section will display the table with the events of individuals.
 return (
   <div>
     <h3>Renginių sąrašas</h3>
     <table className="table table-striped" style={{ marginTop: 20 }}>
       <thead>
         <tr>
           <th>Renginio pavadinimas</th>
           <th>Renginio data</th>
           <th>Veiksmai</th>
         </tr>
       </thead>
       <tbody>{eventList()}</tbody>
     </table>
   </div>
 );
}