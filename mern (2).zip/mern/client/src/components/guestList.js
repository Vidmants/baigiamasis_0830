import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router";

const Guest = (props) => (
 <tr>
   <td>{props.guest.name}</td>
   <td>{props.guest.email}</td>
   <td>{props.guest.date}</td>
   <td>
     <Link className="btn btn-link" to={`/edit/${props.guest._id}`}>Keisti</Link> |
     <button className="btn btn-link"
       onClick={() => {
         props.deleteGuest(props.guest._id);
       }}
     >
       Šalinti
     </button>
   </td>
 </tr>
);
 
export default function GuestList() {
 const [guests, setGuests] = useState([]);
 
 // This method fetches the guests from the database.
 useEffect(() => {
   async function getGuests() {
     const response = await fetch(`http://localhost:5000/guests/${params.id}`);
 
     if (!response.ok) {
       const message = `An error occurred: ${response.statusText}`;
       window.alert(message);
       return;
     }
 
     const guests = await response.json();
     setGuests(guests);
   }
 
   getGuests();
 
   return;
 }, [guests.length]);

 const params = useParams();
 
 // This method will delete a guest
 async function deleteGuest(id) {
   await fetch(`http://localhost:5000/${id}`, {
     method: "DELETE"
   });
 
   const newGuests = guests.filter((el) => el._id !== id);
   setGuests(newGuests);
 }
 
 // This method will map out the guests on the table
 function guestList() {
   return guests.map((guest) => {
     return (
       <Guest
         guest={guest}
         deleteGuest={() => deleteGuest(guest._id)}
         key={guest._id}
       />
     );
   });
 }
 
 // This following section will display the table with the guests of individuals.
 return (
  <div>
    <h3>Vartotojų sąrašas</h3>
    <table className="table table-striped" style={{ marginTop: 20 }}>
      <thead>
        <tr>
          <th>Vardas Pavardė</th>
          <th>El. paštas</th>
          <th>Gimimo data</th>
          <th>Veiksmas</th>
        </tr>
      </thead>
      <tbody>{guestList()}</tbody>
    </table>
  </div>
 );
}