import React, { useState } from "react";
import { useParams, useNavigate } from "react-router";
import DatePicker from "react-datepicker";
 
export default function Create() {
 const [form, setForm] = useState({
   eventid: "", 
   name: "",
   email: "",
   date: (new Date).toISOString().slice(0, 10),
 });

const params = useParams();
const navigate = useNavigate();

 // These methods will update the state properties.
 function updateForm(value) {
   return setForm((prev) => {
     return { ...prev, ...value };
   });
 }
 
 // This function will handle the submission.
 async function onSubmit(e) {
   e.preventDefault();
 
   // When a post request is sent to the create url, we'll add a new guest to the database.
   const newPerson = { ...form };
   newPerson.eventid = params.id;
 
   await fetch("http://localhost:5000/guest/add", {
     method: "POST",
     headers: {
       "Content-Type": "application/json",
     },
     body: JSON.stringify(newPerson),
   })
   .catch(error => {
     window.alert(error);
     return;
   });
 
   setForm({ eventid: "", name: "", email: "", date: (new Date).toISOString().slice(0, 10) });
   navigate("/guests/" + params.id);
 }
 
 // This following section will display the form that takes the input from the user.
 return (
   <div>
     <h3>Sukurti naują vartotoją</h3>
     <form onSubmit={onSubmit}>
       <div className="form-group">
         <label htmlFor="name">Vardas Pavardė</label>
         <input
           type="text"
           className="form-control"
           id="name"
           value={form.name}
           onChange={(e) => updateForm({ name: e.target.value })}
         />
       </div>
       <div className="form-group">
         <label htmlFor="email">El. paštas</label>
         <input
           type="text"
           className="form-control"
           id="email"
           value={form.email}
           onChange={(e) => updateForm({ email: e.target.value })}
         />
       </div>
       <div className="form-group">
         <label htmlFor="date">Gimimo data</label>
         <DatePicker
           dateFormat="yyyy-MM-dd"
           selected={ new Date(form.date) }
           onChange={ (e) => updateForm({ date: e.toISOString().slice(0, 10) }) }
         />
       </div>
       <div className="form-group">
         <input
           type="submit"
           value="Sukurti"
           className="btn btn-primary"
         />
       </div>
     </form>
   </div>
 );
}